# Kasir Nominal V5.2

## Perubahan V5.2
- Menambahkan pengaturan pesan penutup struk pada menu Pengaturan.
- Pesan utama bawaan tetap `Terima kasih`.
- Menambahkan pesan tambahan opsional pada baris berikutnya.
- Pesan disimpan pada tabel settings di database lokal HP, sehingga perubahan dapat dilakukan kapan saja tanpa membangun APK baru.
- Cetak struk baru dan cetak ulang menggunakan pesan penutup yang tersimpan saat itu.
- Versi aplikasi dinaikkan menjadi 5.2 (versionCode 7).

## Yang dipertahankan
- Fitur kasir, katalog, arsip struk, laporan V5.1, database lokal, ekspor CSV, backup/pemulihan, printer Bluetooth, dan sinkronisasi.
