# Kasir Nominal V4 — paket proyek Android

Paket ini disusun dari sumber V4 yang Anda unggah, dengan perapian skema database agar aplikasi dan layanan server lokal memakai tabel inti yang sama. Riwayat transaksi V3 harus tetap dicadangkan sebelum pemasangan/pengujian.

## Isi
- Aplikasi Android native (Java), minSdk 23, targetSdk 32.
- Kasir nominal dengan tombol 00 dan 000.
- Katalog barang: tambah, edit, nonaktifkan, dan pilih barang ke keranjang.
- Riwayat transaksi, detail/cetak ulang, laporan harian/mingguan/bulanan.
- Printer Bluetooth ESC/POS; alamat printer disimpan per HP.
- Identitas toko pada struk, backup/pulihkan CSV.
- Server lokal tertanam (port 8765), token akses, endpoint katalog dan transaksi.
- Antrean transaksi lokal dan tombol sinkronisasi manual ke HP server.
- GitHub Actions untuk membangun APK debug.

## Status fitur sinkronisasi — baca sebelum dipakai
**Yang sudah ada:** transaksi tersimpan lokal saat offline; antrean lokal; pengiriman antrean secara manual saat perangkat terhubung ke server melalui Wi-Fi/LAN; server menolak duplikasi berdasarkan `receipt_id`; katalog dapat ditarik dari server ke HP client.

**Yang belum selesai / belum boleh dianggap tersedia:** sinkronisasi otomatis berkala/background; penarikan arsip transaksi server ke perangkat client; penemuan/pairing perangkat otomatis; batas 10 perangkat dan pengelolaan kasir; server cloud/internet lintas jaringan; failover cloud otomatis; enkripsi TLS. Karena itu paket ini adalah kandidat pengembangan V4, **belum merupakan rilis multi-perangkat siap operasional**. Jangan membuka port server ke internet. Gunakan hanya Wi-Fi toko yang dipercaya.

## Cara build melalui GitHub Actions
1. Ekstrak ZIP ini.
2. Unggah **isi folder proyek** ke root repositori GitHub (bukan ZIP sebagai satu file).
3. Pastikan `.github/workflows/build-apk.yml` berada pada jalur persis tersebut.
4. Buka tab **Actions** → workflow **Build Kasir Nominal V4** → **Run workflow**.
5. Jika status hijau, buka hasil run → **Artifacts** → `KasirNominal-V4-debug`.

## Uji aman
- Jangan uninstall V3 atau menghapus data aplikasi yang sudah berisi transaksi.
- Pasang kandidat V4 hanya setelah backup CSV berhasil dibuat.
- Uji pada HP cadangan/instalasi terpisah bila memungkinkan.
- Uji printer, arsip struk, backup/pulihkan, server lokal, dan sinkronisasi manual dengan transaksi contoh sebelum dipakai untuk penjualan sungguhan.
- Build GitHub Actions belum dijalankan dari paket hasil perapian ini; keberhasilan kompilasi harus dibuktikan dari run baru.

## Catatan cloud
Sinkronisasi melalui internet dari jaringan yang berbeda memerlukan backend cloud yang dapat dijangkau, database pusat, autentikasi perangkat, TLS, dan kebijakan backup. Paket ini belum menyertakan layanan cloud atau kredensial hosting.
