package id.kasirnominal.app;

import android.app.*;
import android.content.*;
import android.os.*;
import android.database.*;
import android.database.sqlite.*;
import org.json.*;
import fi.iki.elonen.NanoHTTPD;
import java.io.*;
import java.util.*;

public class LocalServerService extends Service {
    private StoreHttpServer server;
    private static final int PORT=8765;
    @Override public void onCreate(){super.onCreate();createChannel();startForeground(8765,notification("Server toko sedang aktif"));try{server=new StoreHttpServer(this);server.start(NanoHTTPD.SOCKET_READ_TIMEOUT,false);}catch(Exception e){stopSelf();}}
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){if(server!=null)server.stop();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("kasir_server","Server Kasir Nominal",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    private Notification notification(String s){Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"kasir_server"):new Notification.Builder(this);return b.setContentTitle("Kasir Nominal").setContentText(s).setSmallIcon(android.R.drawable.stat_sys_upload_done).setOngoing(true).build();}

    static class StoreHttpServer extends NanoHTTPD {
        final Context ctx; final SQLiteDatabase db; final String token;
        StoreHttpServer(Context c)throws IOException{super(PORT);ctx=c;SQLiteOpenHelper h=new SQLiteOpenHelper(c,"kasir_nominal.db",null,3){
            public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE IF NOT EXISTS tx(id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_id TEXT UNIQUE, device_id TEXT, created TEXT, day TEXT, total INTEGER, lines TEXT)");d.execSQL("CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT)");d.execSQL("CREATE TABLE IF NOT EXISTS catalog(id TEXT PRIMARY KEY, sku TEXT, name TEXT NOT NULL, category TEXT, price INTEGER NOT NULL, active INTEGER DEFAULT 1, updated_at INTEGER)");d.execSQL("CREATE TABLE IF NOT EXISTS remote_tx(receipt_id TEXT PRIMARY KEY, device_id TEXT, created TEXT, total INTEGER, lines_json TEXT, received_at INTEGER)");d.execSQL("CREATE TABLE IF NOT EXISTS tx_items(id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_id TEXT, product_id TEXT, name TEXT, price INTEGER, qty INTEGER, subtotal INTEGER)");d.execSQL("CREATE TABLE IF NOT EXISTS sync_queue(receipt_id TEXT PRIMARY KEY, payload TEXT NOT NULL, created_at INTEGER, attempts INTEGER DEFAULT 0, last_error TEXT)");}
            public void onUpgrade(SQLiteDatabase d,int o,int n){
                if(o<2){
                    d.execSQL("ALTER TABLE tx RENAME TO tx_old");
                    d.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_id TEXT UNIQUE, device_id TEXT, created TEXT, day TEXT, total INTEGER, lines TEXT)");
                    Cursor c=d.rawQuery("SELECT id,created,day,total,lines FROM tx_old",null);
                    while(c.moveToNext()){ContentValues v=new ContentValues();v.put("receipt_id","LEGACY-"+c.getLong(0));v.put("device_id","legacy");v.put("created",c.getString(1));v.put("day",c.getString(2));v.put("total",c.getLong(3));v.put("lines",c.getString(4));d.insert("tx",null,v);}c.close();d.execSQL("DROP TABLE tx_old");
                }
                onCreate(d);
            }
        };db=h.getWritableDatabase();db.execSQL("CREATE TABLE IF NOT EXISTS tx(id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_id TEXT UNIQUE, device_id TEXT, created TEXT, day TEXT, total INTEGER, lines TEXT)");db.execSQL("CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT)");db.execSQL("CREATE TABLE IF NOT EXISTS catalog(id TEXT PRIMARY KEY, sku TEXT, name TEXT NOT NULL, category TEXT, price INTEGER NOT NULL, active INTEGER DEFAULT 1, updated_at INTEGER)");db.execSQL("CREATE TABLE IF NOT EXISTS remote_tx(receipt_id TEXT PRIMARY KEY, device_id TEXT, created TEXT, total INTEGER, lines_json TEXT, received_at INTEGER)");db.execSQL("CREATE TABLE IF NOT EXISTS tx_items(id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_id TEXT, product_id TEXT, name TEXT, price INTEGER, qty INTEGER, subtotal INTEGER)");db.execSQL("CREATE TABLE IF NOT EXISTS sync_queue(receipt_id TEXT PRIMARY KEY, payload TEXT NOT NULL, created_at INTEGER, attempts INTEGER DEFAULT 0, last_error TEXT)");
            android.content.SharedPreferences p=c.getSharedPreferences("server_config",0);String t=p.getString("token",null);if(t==null){t=UUID.randomUUID().toString().replace("-","");p.edit().putString("token",t).apply();}token=t;}
        @Override public Response serve(IHTTPSession s){
            String path=s.getUri(),method=s.getMethod().name();
            if(path.equals("/health")&&method.equals("GET")){try{JSONObject h=new JSONObject();h.put("ok",true);h.put("service","Kasir Nominal Local Server");h.put("port",PORT);return json(h);}catch(Exception e){return newFixedLengthResponse(Response.Status.INTERNAL_ERROR,"application/json","{\"ok\":false}");}}
            if(!token.equals(s.getHeaders().get("x-store-token")))return newFixedLengthResponse(Response.Status.UNAUTHORIZED,"application/json","{\"error\":\"unauthorized\"}");
            try{
                if(path.equals("/api/catalog")&&method.equals("GET"))return catalog();
                if(path.equals("/api/catalog")&&method.equals("POST"))return saveCatalog(s);
                if(path.equals("/api/receipts")&&method.equals("POST"))return receiveReceipt(s);
                if(path.equals("/api/receipts")&&method.equals("GET"))return receipts();
                if(path.equals("/api/sync")&&method.equals("GET"))return syncSnapshot();
                return newFixedLengthResponse(Response.Status.NOT_FOUND,"application/json","{\"error\":\"not_found\"}");
            }catch(Exception e){return newFixedLengthResponse(Response.Status.BAD_REQUEST,"application/json","{\"error\":\""+safe(e.getMessage())+"\"}");}
        }
        Response catalog()throws Exception{JSONArray a=new JSONArray();Cursor c=db.rawQuery("SELECT id,sku,name,category,price,active,updated_at FROM catalog ORDER BY name",null);while(c.moveToNext()){JSONObject o=new JSONObject();o.put("id",c.getString(0));o.put("sku",c.getString(1));o.put("name",c.getString(2));o.put("category",c.getString(3));o.put("price",c.getLong(4));o.put("active",c.getInt(5)==1);o.put("updated_at",c.getLong(6));a.put(o);}c.close();return json(new JSONObject().put("items",a));}
        Response saveCatalog(IHTTPSession s)throws Exception{JSONObject o=body(s);String id=o.optString("id","");String name=o.optString("name","").trim();long price=o.optLong("price",-1);if(id.isEmpty()||name.isEmpty()||price<0)throw new Exception("id, name, price wajib");ContentValues v=new ContentValues();v.put("id",id);v.put("sku",o.optString("sku",""));v.put("name",name);v.put("category",o.optString("category",""));v.put("price",price);v.put("active",o.optBoolean("active",true)?1:0);v.put("updated_at",System.currentTimeMillis());db.insertWithOnConflict("catalog",null,v,SQLiteDatabase.CONFLICT_REPLACE);return json(new JSONObject().put("saved",true).put("id",id));}
        Response receiveReceipt(IHTTPSession s)throws Exception{JSONObject o=body(s);String id=o.optString("receipt_id","");if(id.isEmpty())throw new Exception("receipt_id wajib");ContentValues v=new ContentValues();v.put("receipt_id",id);v.put("device_id",o.optString("device_id",""));v.put("created",o.optString("created",""));v.put("total",o.optLong("total",0));v.put("lines_json",o.optJSONArray("lines")==null?"[]":o.getJSONArray("lines").toString());v.put("received_at",System.currentTimeMillis());long result=db.insertWithOnConflict("remote_tx",null,v,SQLiteDatabase.CONFLICT_IGNORE);
            if(result!=-1){String created=o.optString("created",new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss",java.util.Locale.US).format(new java.util.Date()));String day=created.length()>=10?created.substring(0,10):created;ContentValues tx=new ContentValues();tx.put("receipt_id",id);tx.put("device_id",o.optString("device_id",""));tx.put("created",created);tx.put("day",day);tx.put("total",o.optLong("total",0));tx.put("lines","");db.insertWithOnConflict("tx",null,tx,SQLiteDatabase.CONFLICT_IGNORE);
                JSONArray lines=o.optJSONArray("lines");if(lines!=null){for(int i=0;i<lines.length();i++){JSONObject line=lines.optJSONObject(i);if(line==null||!line.has("product_id"))continue;ContentValues item=new ContentValues();item.put("receipt_id",id);item.put("product_id",line.optString("product_id",""));item.put("name",line.optString("name","Barang"));item.put("price",line.optLong("price",0));item.put("qty",line.optLong("qty",0));item.put("subtotal",line.optLong("subtotal",0));db.insert("tx_items",null,item);}}
            }
            return json(new JSONObject().put("accepted",result!=-1).put("duplicate",result==-1).put("receipt_id",id));}
        Response receipts()throws Exception{JSONArray a=new JSONArray();Cursor c=db.rawQuery("SELECT receipt_id,device_id,created,total,lines_json FROM remote_tx ORDER BY received_at DESC LIMIT 1000",null);while(c.moveToNext()){JSONObject o=new JSONObject();o.put("receipt_id",c.getString(0));o.put("device_id",c.getString(1));o.put("created",c.getString(2));o.put("total",c.getLong(3));o.put("lines",new JSONArray(c.getString(4)));a.put(o);}c.close();return json(new JSONObject().put("items",a));}
        Response syncSnapshot()throws Exception{JSONObject result=new JSONObject();result.put("catalog",catalogItems());result.put("receipts",receiptItems());return json(result);}
        JSONArray catalogItems()throws Exception{JSONArray a=new JSONArray();Cursor c=db.rawQuery("SELECT id,sku,name,category,price,active,updated_at FROM catalog ORDER BY name",null);while(c.moveToNext()){JSONObject o=new JSONObject();o.put("id",c.getString(0));o.put("sku",c.getString(1));o.put("name",c.getString(2));o.put("category",c.getString(3));o.put("price",c.getLong(4));o.put("active",c.getInt(5)==1);o.put("updated_at",c.getLong(6));a.put(o);}c.close();return a;}
        JSONArray receiptItems()throws Exception{JSONArray a=new JSONArray();Cursor c=db.rawQuery("SELECT receipt_id,device_id,created,total,lines_json FROM remote_tx ORDER BY received_at DESC LIMIT 1000",null);while(c.moveToNext()){JSONObject o=new JSONObject();o.put("receipt_id",c.getString(0));o.put("device_id",c.getString(1));o.put("created",c.getString(2));o.put("total",c.getLong(3));o.put("lines",new JSONArray(c.getString(4)));a.put(o);}c.close();return a;}
        JSONObject body(IHTTPSession s)throws Exception{Map<String,String> files=new HashMap<>();s.parseBody(files);String raw=files.get("postData");if(raw==null||raw.isEmpty())throw new Exception("body kosong");return new JSONObject(raw);}
        Response json(JSONObject o){return newFixedLengthResponse(Response.Status.OK,"application/json; charset=utf-8",o.toString());}
        String safe(String x){return x==null?"error":x.replace("\"","'").replace("\n"," ");}
    }
}
