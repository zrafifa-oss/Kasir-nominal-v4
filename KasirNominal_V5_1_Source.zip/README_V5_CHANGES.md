# Kasir Nominal V5 — perubahan dari V4

## Perubahan V5
- Versi aplikasi dinaikkan menjadi 5.0 (versionCode 5).
- Ikon aplikasi memakai identitas visual hijau-emas Kasir Nominal V5.
- Cetak struk: header toko tetap rata tengah; setelah header ada garis putus-putus; nomor transaksi, tanggal, kasir, daftar nominal dan rincian barang dicetak rata kiri; garis putus-putus kedua memisahkan daftar dari TOTAL; ucapan terima kasih tetap rata tengah.
- Laporan menampilkan periode, jumlah transaksi, total omzet gabungan, dan rincian transaksi satu per satu (tanggal/jam, nomor transaksi, nominal). Ketuk baris untuk membuka detail struk.
- Arsip, katalog, database lokal, backup/restore, sinkronisasi, dan printer Bluetooth dipertahankan.

## Build
Workflow GitHub Actions tersedia di `.github/workflows/build-v5.yml` dan dapat dijalankan melalui Actions → Build Kasir Nominal V5 → Run workflow.

## Catatan instalasi
APK debug hasil runner GitHub mungkin memiliki tanda tangan debug yang berbeda dari APK debug sebelumnya. Android dapat menolak pemasangan sebagai update. Jangan hapus aplikasi yang sudah ada sebelum memastikan data telah dibackup; bila signature berbeda dan data uji boleh dihapus, uninstall aplikasi lama lalu instal APK V5.
