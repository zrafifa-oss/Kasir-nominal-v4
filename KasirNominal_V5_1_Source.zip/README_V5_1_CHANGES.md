# Kasir Nominal V5.1 — perbaikan laporan

Perubahan khusus dari V5:
- Bagian periode tetap menampilkan periode dan jumlah transaksi.
- Rincian transaksi hanya menampilkan urutan dan total rupiah per transaksi (contoh: `1. Rp7.000`). Tidak menampilkan ID transaksi maupun tanggal/jam pada daftar.
- TOTAL OMZET gabungan ditampilkan setelah seluruh rincian transaksi.
- Setiap baris rincian tetap dapat diketuk untuk membuka detail struk.
- Tidak mengubah kasir, katalog, arsip struk, pengaturan, database, backup/restore, sinkronisasi, atau printer.
- Version name 5.1, version code 6.
