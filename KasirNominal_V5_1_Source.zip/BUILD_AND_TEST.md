# Build dan checklist pengujian V4

## Build
Gunakan GitHub Actions pada `.github/workflows/build-apk.yml`. Hasil yang diharapkan adalah `app-debug.apk`. Jangan menganggap paket siap rilis hanya karena proses build sukses.

## Checklist minimum
- [ ] APK terpasang tanpa menghapus V3 dan data lama.
- [ ] Tambah/edit/nonaktifkan barang.
- [ ] Transaksi nominal dan transaksi katalog tersimpan.
- [ ] Struk 58 mm tercetak dan bisa dicetak ulang.
- [ ] Backup CSV dapat dibuat dan dipulihkan pada salinan data.
- [ ] HP server dan HP client pada Wi-Fi yang sama.
- [ ] Client mengirim transaksi antrean secara manual ke server.
- [ ] Kirim ulang receipt ID yang sama dan pastikan tidak menggandakan omzet.
- [ ] Katalog server ditarik ke client.
- [ ] Matikan Wi-Fi, buat transaksi, hidupkan Wi-Fi, lalu sinkronkan.
- [ ] Restart HP server dan uji ulang layanan.

## Batas keselamatan
Jangan menguji migrasi pada satu-satunya database transaksi aktif. Buat backup terlebih dahulu. HTTP lokal belum memakai TLS; jangan port-forward server ke internet.
