# Kasir Nominal — kandidat fondasi multi-perangkat

## Isi kandidat
- Aplikasi Android kasir lokal yang menjadi basis dari versi 3.
- Katalog barang lokal (tambah, edit, nonaktifkan).
- Arsip struk dan cetak ulang (fitur dari kandidat sebelumnya).
- Laporan dan backup CSV (fitur dari kandidat sebelumnya).
- Layanan HTTP lokal tertanam pada HP server (NanoHTTPD), port 8765.
- Endpoint server: `GET /health`, `GET /api/catalog`, `POST /api/catalog`,
  `POST /api/receipts`, `GET /api/receipts`, `GET /api/sync`.
- Header autentikasi API: `X-Store-Token`, token dibuat acak dan disimpan di SharedPreferences.
- Penyimpanan remote transaction memakai `receipt_id` unik agar POST ulang tidak menggandakan transaksi.

## Uji build
Upload isi folder proyek ke root repositori atau gunakan workflow terlampir. Jalankan GitHub Actions dan periksa log kompilasi.

## Batasan penting — belum siap operasional multi-kasir
Ini adalah fondasi awal server lokal dan katalog, bukan sistem sinkronisasi lengkap.
- Belum ada aplikasi client yang mengirim antrean transaksi offline otomatis.
- Belum ada mekanisme pairing perangkat / manajemen 10 kasir.
- Server lokal perlu HP host dan perangkat client berada pada LAN/Wi-Fi yang sama.
- Android dapat menghentikan layanan latar belakang karena penghematan baterai; foreground service membantu tetapi perlu pengujian pada merek HP.
- Server lokal belum otomatis failover ke cloud.
- Endpoint HTTP LAN memakai token, tetapi belum memakai TLS; gunakan hanya jaringan Wi-Fi toko yang dipercaya. Jangan expose port ke internet.
- Server lokal dan aplikasi kasir berbagi database SQLite; uji migrasi dan backup pada salinan sebelum mengganti versi 3.
- Printer per perangkat harus tetap dikonfigurasi di tiap HP.
