package id.kasirnominal.app;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.security.MessageDigest;

public class MainActivity extends Activity {
    DB db; TextView display,totalView,linesView; String entry="0";
    ArrayList<Long> current=new ArrayList<>();
    ArrayList<CartItem> cartItems=new ArrayList<>();
    LinearLayout root,content;
    static class CartItem { String productId,name; long price,qty; CartItem(String i,String n,long p,long q){productId=i;name=n;price=p;qty=q;} long subtotal(){return price*qty;} }

    String tab="kasir"; static final Locale ID=new Locale("id","ID");
    static final int CREATE_BACKUP=101, RESTORE_BACKUP=102, EXPORT_CSV=103;
    String pendingExport="";
    String money(long n){return "Rp"+NumberFormat.getIntegerInstance(ID).format(Math.abs(n));}
    long total(){long s=0;for(long n:current)s+=n;for(CartItem item:cartItems)s+=item.subtotal();return s;}
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(Bundle b){super.onCreate(b);db=new DB(this);showKasir();}
    TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xff17211b);if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(dp(5),dp(7),dp(5),dp(7));return t;}
    Button button(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setOnClickListener(v->r.run());return b;}
    LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(dp(12),dp(8),dp(12),dp(8));return l;}
    void base(String title){root=vertical();root.setBackgroundColor(0xfff3f6f4);TextView h=text(title,21,true);h.setTextColor(-1);h.setBackgroundColor(0xff14532d);h.setPadding(dp(16),dp(16),dp(16),dp(16));root.addView(h);
        LinearLayout nav=new LinearLayout(this);nav.addView(button("Kasir",()->showKasir()),new LinearLayout.LayoutParams(0,dp(48),1));nav.addView(button("Riwayat",()->showHistory()),new LinearLayout.LayoutParams(0,dp(48),1));nav.addView(button("Katalog",()->showCatalog()),new LinearLayout.LayoutParams(0,dp(48),1));nav.addView(button("Laporan",()->showReport()),new LinearLayout.LayoutParams(0,dp(48),1));nav.addView(button("Pengaturan",()->showSettings()),new LinearLayout.LayoutParams(0,dp(48),1));root.addView(nav);
        ScrollView sc=new ScrollView(this);content=vertical();sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    void add(View v){content.addView(v,new LinearLayout.LayoutParams(-1,-2));}
    void digit(String d){entry=(entry.equals("0")?d:entry+d);if(entry.length()>13)entry=entry.substring(0,13);refresh();}
    void addLine(long sign){long n=parseEntry();if(n>0)current.add(n*sign);entry="0";refresh();}
    long parseEntry(){try{return Long.parseLong(entry);}catch(Exception e){return 0;}}
    void refresh(){if(display!=null)display.setText(money(parseEntry()));if(totalView!=null)totalView.setText("TOTAL  "+(total()<0?"-":"")+money(total()));if(linesView!=null){StringBuilder s=new StringBuilder();for(int i=0;i<current.size();i++)s.append(i+1).append(". ").append(current.get(i)<0?"Pengurang  -":"Nominal  ").append(money(current.get(i))).append("\n");if(current.isEmpty())s.append("Belum ada nominal.");linesView.setText(s.toString());}}
    void showKasir(){tab="kasir";base("KASIR NOMINAL");add(text("NOMINAL",12,true));display=text(money(parseEntry()),30,true);display.setGravity(Gravity.RIGHT);add(display);
        GridLayout g=new GridLayout(this);g.setColumnCount(4);String[] keys={"7","8","9","⌫","4","5","6","C","1","2","3","−","00","0","000","+"};
        for(String k:keys){Button b=button(k,()->{if(k.matches("[0-9]+"))digit(k);else if(k.equals("+"))addLine(1);else if(k.equals("−"))addLine(-1);else if(k.equals("C")){entry="0";refresh();}else{entry=entry.length()>1?entry.substring(0,entry.length()-1):"0";refresh();}});
            GridLayout.LayoutParams lp=new GridLayout.LayoutParams();lp.width=0;lp.height=dp(56);lp.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);lp.setMargins(dp(3),dp(3),dp(3),dp(3));g.addView(b,lp);}add(g);
        add(button("PILIH BARANG DARI KATALOG",()->showProductPicker()));
        add(button("= HITUNG SUBTOTAL",()->{addLine(1);toast("Subtotal: "+money(total()));}));totalView=text("TOTAL "+money(total()),22,true);add(totalView);linesView=text("",15,false);add(linesView);
        add(button("Batalkan baris terakhir",()->{if(!current.isEmpty())current.remove(current.size()-1);refresh();}));
        add(button("Kosongkan transaksi",()->new AlertDialog.Builder(this).setTitle("Kosongkan transaksi?").setNegativeButton("Batal",null).setPositiveButton("Kosongkan",(d,w)->{current.clear();entry="0";refresh();}).show()));
        add(button("SIMPAN TRANSAKSI & CETAK STRUK",()->saveAndPrint()));refresh();}
    void saveAndPrint(){if(current.isEmpty()&&cartItems.isEmpty()){toast("Masukkan nominal atau pilih barang terlebih dahulu");return;}long sum=total();if(sum<0){toast("Total tidak boleh negatif");return;}
        String device=db.setting("device_id",makeId());db.setSetting("device_id",device);String receiptId=device.substring(0,Math.min(6,device.length()))+"-"+System.currentTimeMillis();
        long id=db.insert(receiptId,device,current,sum);
        db.saveReceiptItems(receiptId,cartItems,current);
        ArrayList<Long> copy=new ArrayList<>(current);
        current.clear();cartItems.clear();entry="0";refresh();printReceipt(id,copy,sum);toast("Transaksi tersimpan lokal; siap disinkronkan saat terhubung");}
    String makeId(){return UUID.randomUUID().toString();}
    void showProductPicker(){
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,price FROM catalog WHERE active=1 ORDER BY name",null);
        ArrayList<String> labels=new ArrayList<>();ArrayList<String> ids=new ArrayList<>();ArrayList<Long> prices=new ArrayList<>();
        while(c.moveToNext()){ids.add(c.getString(0));labels.add(c.getString(1)+" | "+money(c.getLong(2)));prices.add(c.getLong(2));}c.close();
        if(labels.isEmpty()){toast("Katalog masih kosong. Tambahkan barang di menu Katalog.");return;}
        new AlertDialog.Builder(this).setTitle("Pilih barang").setItems(labels.toArray(new String[0]),(d,which)->{
            String id=ids.get(which);Cursor p=db.getReadableDatabase().rawQuery("SELECT name,price FROM catalog WHERE id=?",new String[]{id});
            if(p.moveToFirst()){String name=p.getString(0);long price=p.getLong(1);p.close();EditText qty=field("Jumlah","1");
                new AlertDialog.Builder(this).setTitle(name).setMessage("Harga satuan: "+money(price)).setView(qty).setNegativeButton("Batal",null).setPositiveButton("Tambah",(dd,w)->{try{long q=Long.parseLong(qty.getText().toString().trim());if(q<1||q>1000000)throw new Exception();cartItems.add(new CartItem(id,name,price,q));refresh();toast("Barang masuk keranjang");}catch(Exception ex){toast("Jumlah tidak valid");}}).show();
            }else p.close();
        }).setNegativeButton("Tutup",null).show();
    }
    void showCatalog(){base("KATALOG BARANG");EditText sku=field("Kode barang / SKU","");EditText name=field("Nama barang","");EditText category=field("Kategori","");EditText price=field("Harga jual (angka)","");add(text("Tambah barang",17,true));add(sku);add(name);add(category);add(price);
        add(button("Simpan barang",()->{try{String n=name.getText().toString().trim();long p=Long.parseLong(price.getText().toString().trim());if(n.isEmpty()||p<0)throw new Exception();ContentValues v=new ContentValues();String id=UUID.randomUUID().toString();v.put("id",id);v.put("sku",sku.getText().toString());v.put("name",n);v.put("category",category.getText().toString());v.put("price",p);v.put("active",1);v.put("updated_at",System.currentTimeMillis());db.getWritableDatabase().insert("catalog",null,v);toast("Barang disimpan");showCatalog();}catch(Exception e){toast("Isi nama dan harga dengan benar");}}));
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,sku,name,price FROM catalog WHERE active=1 ORDER BY name",null);while(c.moveToNext()){String id=c.getString(0);add(button(c.getString(2)+" | "+money(c.getLong(3))+"  ✎",()->editProduct(id)));}c.close();}
    void editProduct(String id){Cursor c=db.getReadableDatabase().rawQuery("SELECT sku,name,category,price FROM catalog WHERE id=?",new String[]{id});if(!c.moveToFirst()){c.close();return;}String[] old={c.getString(0),c.getString(1),c.getString(2),""+c.getLong(3)};c.close();LinearLayout box=vertical();EditText[] e={field("SKU",old[0]),field("Nama",old[1]),field("Kategori",old[2]),field("Harga",old[3])};for(EditText x:e)box.addView(x);new AlertDialog.Builder(this).setTitle("Edit barang").setView(box).setNegativeButton("Batal",null).setNeutralButton("Nonaktifkan",(d,w)->{ContentValues v=new ContentValues();v.put("active",0);db.getWritableDatabase().update("catalog",v,"id=?",new String[]{id});showCatalog();}).setPositiveButton("Simpan",(d,w)->{try{ContentValues v=new ContentValues();v.put("sku",e[0].getText().toString());v.put("name",e[1].getText().toString());v.put("category",e[2].getText().toString());v.put("price",Long.parseLong(e[3].getText().toString()));v.put("updated_at",System.currentTimeMillis());db.getWritableDatabase().update("catalog",v,"id=?",new String[]{id});showCatalog();}catch(Exception ex){toast("Harga tidak valid");}}).show();}
    void showHistory(){base("ARSIP STRUK");EditText q=new EditText(this);q.setHint("Cari nomor transaksi / tanggal");add(q);LinearLayout list=vertical();add(list);Runnable render=()->{list.removeAllViews();Cursor c=db.search(q.getText().toString());while(c.moveToNext()){long id=c.getLong(0),sum=c.getLong(1);String rid=c.getString(2),created=c.getString(3);list.addView(button(rid+" | "+created+" | "+money(sum),()->showReceipt(id)));}c.close();if(list.getChildCount()==0)list.addView(text("Belum ada transaksi.",15,false));};add(button("Cari / Muat ulang",render));render.run();}
    void showReceipt(long id){Cursor c=db.one(id);if(!c.moveToFirst()){c.close();return;}String rid=c.getString(0),created=c.getString(1),lines=c.getString(2);long sum=c.getLong(3);c.close();StringBuilder b=new StringBuilder("No: ").append(rid).append("\n").append(created).append("\n");String[] a=lines.split("\\|");for(int i=0;i<a.length;i++){long n=Long.parseLong(a[i]);b.append(i+1).append(". ").append(n<0?"-":"").append(money(n)).append("\n");}
        Cursor items=db.getReadableDatabase().rawQuery("SELECT name,price,qty,subtotal FROM tx_items WHERE receipt_id=?",new String[]{rid});while(items.moveToNext())b.append(items.getString(0)).append(" x").append(items.getLong(2)).append(" @ ").append(money(items.getLong(1))).append(" = ").append(money(items.getLong(3))).append("\n");items.close();b.append("TOTAL  ").append(money(sum)).append("\n");
        new AlertDialog.Builder(this).setTitle("Detail struk").setMessage(b.toString()).setNeutralButton("Cetak ulang",(d,w)->printReceipt(id,parseLines(lines),sum)).setPositiveButton("Tutup",null).show();}
    ArrayList<Long> parseLines(String s){ArrayList<Long>a=new ArrayList<>();for(String x:s.split("\\|"))try{a.add(Long.parseLong(x));}catch(Exception ignored){}return a;}
    void showReport(){base("LAPORAN");String today=new SimpleDateFormat("yyyy-MM-dd",ID).format(new Date());TextView summary=text("",17,true);add(summary);LinearLayout detailList=vertical();
        add(button("Hari ini",()->renderReport(summary,detailList,"day",today)));add(button("7 hari terakhir",()->renderReport(summary,detailList,"week",today)));add(button("Bulan ini",()->renderReport(summary,detailList,"month",today)));add(detailList);
        renderReport(summary,detailList,"day",today);add(button("Ekspor CSV",()->exportCsv()));add(button("Backup database",()->createBackup()));add(button("Pulihkan backup",()->restoreBackup()));}
    void renderReport(TextView v,LinearLayout detailList,String period,String today){Cursor c=db.report(period,today);long sum=0;int count=0;ArrayList<long[]> rows=new ArrayList<>();ArrayList<String[]> labels=new ArrayList<>();while(c.moveToNext()){sum+=c.getLong(1);count++;rows.add(new long[]{c.getLong(0),c.getLong(1)});labels.add(new String[]{c.getString(2),c.getString(3)});}c.close();String periodLabel=period.equals("day")?"Hari ini":period.equals("week")?"7 hari terakhir":"Bulan ini";v.setText("Periode: "+periodLabel+"\nJumlah transaksi: "+count+"\nTOTAL OMZET: "+money(sum));detailList.removeAllViews();detailList.addView(text("RINCIAN TRANSAKSI",17,true));if(rows.isEmpty()){detailList.addView(text("Belum ada transaksi pada periode ini.",14,false));return;}for(int i=0;i<rows.size();i++){final long txId=rows.get(i)[0];String receipt=labels.get(i)[0],created=labels.get(i)[1];String label=(i+1)+". "+created+"\n"+receipt+"\n"+money(rows.get(i)[1]);detailList.addView(button(label,()->showReceipt(txId)));}}
    void showSettings(){base("PENGATURAN TOKO");EditText name=field("Nama toko",db.setting("store_name","Kasir Nominal"));EditText address=field("Alamat",db.setting("store_address",""));EditText phone=field("Nomor telepon",db.setting("store_phone",""));EditText device=field("Nama perangkat/kasir",db.setting("device_name","Kasir 1"));
        add(name);add(address);add(phone);add(device);add(button("Simpan identitas toko",()->{db.setSetting("store_name",name.getText().toString());db.setSetting("store_address",address.getText().toString());db.setSetting("store_phone",phone.getText().toString());db.setSetting("device_name",device.getText().toString());toast("Pengaturan disimpan");}));
        add(text("Printer Bluetooth",17,true));add(button("Pilih / ganti printer",()->choosePrinter(new byte[0],true)));String mac=db.setting("printer_mac","");add(text(mac.isEmpty()?"Belum ada printer tersimpan":"Printer tersimpan: "+mac,14,false));add(button("Lupakan printer",()->{db.setSetting("printer_mac","");db.setSetting("printer_name","");toast("Printer dilepas");showSettings();}));
        add(text("SERVER LOKAL TOKO",17,true));
        add(button("Aktifkan server di HP ini",()->{Intent i=new Intent(this,LocalServerService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);toast("Server lokal dimulai. Pastikan HP dan kasir lain pada Wi-Fi yang sama.");}));
        add(button("Hentikan server",()->{stopService(new Intent(this,LocalServerService.class));toast("Server dihentikan");}));
        String token=getSharedPreferences("server_config",0).getString("token","Dibuat saat server pertama dijalankan");add(text("Token akses: "+token,12,false));
        add(text("Alamat server menggunakan IP Wi-Fi HP ini dengan port 8765. Endpoint /health untuk tes koneksi.",12,false));
        add(text("SINKRONISASI KE HP SERVER",17,true));
        EditText serverUrl=field("Alamat server, contoh http://192.168.1.10:8765",db.setting("server_url",""));
        EditText serverToken=field("Token server",db.setting("server_token",""));
        add(serverUrl);add(serverToken);
        add(button("Simpan koneksi server",()->{db.setSetting("server_url",serverUrl.getText().toString().trim());db.setSetting("server_token",serverToken.getText().toString().trim());toast("Alamat dan token server disimpan");}));
        add(button("SINKRONKAN SEKARANG",()->syncWithServer()));
        add(text("Transaksi tetap tersimpan di HP ini saat offline. Sinkronkan saat HP terhubung ke Wi-Fi server.",12,false));}
    String readStream(InputStream in)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toString("UTF-8");}
    void syncWithServer(){
        String baseUrl=db.setting("server_url","").trim(),token=db.setting("server_token","").trim();
        if(baseUrl.isEmpty()||token.isEmpty()){toast("Isi alamat dan token server terlebih dahulu");return;}
        new Thread(()->{int sent=0;String error=null;
            try{
                android.database.Cursor q=db.getReadableDatabase().rawQuery("SELECT receipt_id,payload FROM sync_queue ORDER BY created_at LIMIT 200",null);
                ArrayList<String[]> pending=new ArrayList<>();while(q.moveToNext())pending.add(new String[]{q.getString(0),q.getString(1)});q.close();
                for(String[] row:pending){java.net.HttpURLConnection con=(java.net.HttpURLConnection)new java.net.URL(baseUrl+"/api/receipts").openConnection();con.setRequestMethod("POST");con.setConnectTimeout(5000);con.setReadTimeout(7000);con.setDoOutput(true);con.setRequestProperty("Content-Type","application/json");con.setRequestProperty("x-store-token",token);con.getOutputStream().write(row[1].getBytes("UTF-8"));int code=con.getResponseCode();if(code>=200&&code<300){db.getWritableDatabase().delete("sync_queue","receipt_id=?",new String[]{row[0]});sent++;}else throw new Exception("Server menolak transaksi (HTTP "+code+")");con.disconnect();}
                java.net.HttpURLConnection cat=(java.net.HttpURLConnection)new java.net.URL(baseUrl+"/api/catalog").openConnection();cat.setConnectTimeout(5000);cat.setReadTimeout(7000);cat.setRequestProperty("x-store-token",token);if(cat.getResponseCode()==200){String raw=readStream(cat.getInputStream());org.json.JSONArray items=new org.json.JSONObject(raw).optJSONArray("items");if(items!=null){SQLiteDatabase d=db.getWritableDatabase();d.beginTransaction();try{for(int i=0;i<items.length();i++){org.json.JSONObject o=items.getJSONObject(i);ContentValues v=new ContentValues();v.put("id",o.getString("id"));v.put("sku",o.optString("sku",""));v.put("name",o.getString("name"));v.put("category",o.optString("category",""));v.put("price",o.optLong("price"));v.put("active",o.optBoolean("active",true)?1:0);v.put("updated_at",o.optLong("updated_at"));d.insertWithOnConflict("catalog",null,v,SQLiteDatabase.CONFLICT_REPLACE);}d.setTransactionSuccessful();}finally{d.endTransaction();}}}cat.disconnect();
            }catch(Exception e){error=e.getMessage();}
            final int done=sent;final String err=error;runOnUiThread(()->toast(err==null?"Sinkronisasi selesai. Transaksi terkirim: "+done:"Sinkronisasi belum selesai: "+err));
        }).start();
    }
    EditText field(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setSingleLine(true);return e;}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    void printReceipt(long id,ArrayList<Long> lines,long sum){StringBuilder header=new StringBuilder();header.append(db.setting("store_name","Kasir Nominal")).append("\n");String address=db.setting("store_address","").trim(),phone=db.setting("store_phone","").trim();if(!address.isEmpty())header.append(address).append("\n");if(!phone.isEmpty())header.append(phone).append("\n");Cursor c=db.one(id);String rid="",created="";if(c.moveToFirst()){rid=c.getString(0);created=c.getString(1);}c.close();StringBuilder detail=new StringBuilder();detail.append(dashLine()).append("\nNo: ").append(rid).append("\n").append(created).append("\nKasir: ").append(db.setting("device_name","Kasir")).append("\n");for(int i=0;i<lines.size();i++)detail.append(i+1).append(". ").append(lines.get(i)<0?"-":"").append(money(lines.get(i))).append("\n");
        Cursor items=db.getReadableDatabase().rawQuery("SELECT name,price,qty,subtotal FROM tx_items WHERE receipt_id=?",new String[]{rid});while(items.moveToNext())detail.append(items.getString(0)).append(" x").append(items.getLong(2)).append(" @ ").append(money(items.getLong(1))).append(" = ").append(money(items.getLong(3))).append("\n");items.close();detail.append(dashLine()).append("\nTOTAL  ").append(money(sum)).append("\n");try{sendToSavedPrinter(escpos(header.toString(),detail.toString()));}catch(Exception e){toast("Gagal menyiapkan struk");}}
    String dashLine(){StringBuilder s=new StringBuilder();for(int i=0;i<32;i++)s.append('-');return s.toString();}
    byte[] escpos(String header,String detail)throws Exception{ByteArrayOutputStream o=new ByteArrayOutputStream();o.write(new byte[]{0x1b,0x40});o.write(new byte[]{0x1b,0x61,1});o.write(header.getBytes("CP437"));o.write(new byte[]{0x1b,0x61,0});o.write(detail.getBytes("CP437"));o.write(new byte[]{0x1b,0x61,1});o.write("\nTerima kasih\n\n\n".getBytes("CP437"));o.write(new byte[]{0x1d,0x56,0x41,0x10});return o.toByteArray();}
    void ensureBt(){if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},44);}
    void choosePrinter(byte[] data,boolean saveOnly){ensureBt();try{BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null){toast("Bluetooth tidak tersedia");return;}if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){toast("Izinkan akses Bluetooth lalu ulangi");return;}ArrayList<BluetoothDevice> ds=new ArrayList<>(a.getBondedDevices());if(ds.isEmpty()){toast("Pairing printer dari pengaturan Bluetooth Android terlebih dahulu");return;}String[] names=new String[ds.size()];for(int i=0;i<ds.size();i++)names[i]=ds.get(i).getName()+" ("+ds.get(i).getAddress()+")";
        new AlertDialog.Builder(this).setTitle("Pilih printer").setItems(names,(d,w)->{BluetoothDevice dev=ds.get(w);db.setSetting("printer_mac",dev.getAddress());db.setSetting("printer_name",dev.getName());toast("Printer tersimpan: "+dev.getName());if(!saveOnly)connectPrint(dev,data);}).setNegativeButton("Batal",null).show();}catch(Exception e){toast("Tidak dapat membaca perangkat Bluetooth");}}
    void sendToSavedPrinter(byte[] data){String mac=db.setting("printer_mac","");if(mac.isEmpty()){choosePrinter(data,false);return;}try{BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null)throw new Exception();if(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){ensureBt();toast("Izinkan Bluetooth lalu tekan cetak lagi");return;}BluetoothDevice d=a.getRemoteDevice(mac);connectPrint(d,data);}catch(Exception e){toast("Printer tersimpan tidak ditemukan. Pilih ulang di Pengaturan.");}}
    void connectPrint(BluetoothDevice dev,byte[] data){new Thread(()->{try{BluetoothSocket s=dev.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));s.connect();OutputStream o=s.getOutputStream();o.write(data);o.flush();o.close();s.close();runOnUiThread(()->toast("Struk dikirim ke "+dev.getName()));}catch(Exception e){runOnUiThread(()->toast("Gagal terhubung. Pastikan printer hidup dan sudah dipasangkan."));}}).start();}
    void createBackup(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"kasir-nominal-backup.csv");startActivityForResult(i,CREATE_BACKUP);}
    void exportCsv(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"laporan-kasir-nominal.csv");startActivityForResult(i,EXPORT_CSV);}
    void restoreBackup(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,RESTORE_BACKUP);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;try{Uri u=data.getData();if(req==CREATE_BACKUP){OutputStream o=getContentResolver().openOutputStream(u);db.writeCsv(o);o.close();toast("Backup berhasil disimpan");}else if(req==EXPORT_CSV){OutputStream o=getContentResolver().openOutputStream(u);db.writeCsv(o);o.close();toast("Ekspor CSV berhasil");}else if(req==RESTORE_BACKUP){InputStream in=getContentResolver().openInputStream(u);db.restoreCsv(in);in.close();toast("Pemulihan selesai. Periksa arsip transaksi.");}}catch(Exception e){toast("Operasi file gagal: "+e.getMessage());}}
    class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"kasir_nominal.db",null,3);}
        public void onCreate(SQLiteDatabase d){ensureSchema(d);}
        public void onUpgrade(SQLiteDatabase d,int old,int n){
            // Preserve V3 transaction history while upgrading the shared database.
            if(old<2 && tableExists(d,"tx") && !columnExists(d,"tx","receipt_id")){
                d.execSQL("ALTER TABLE tx RENAME TO tx_legacy_v1");
                d.execSQL("CREATE TABLE IF NOT EXISTS tx(id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_id TEXT UNIQUE, device_id TEXT, created TEXT, day TEXT, total INTEGER, lines TEXT)");
                Cursor c=d.rawQuery("SELECT id,created,day,total,lines FROM tx_legacy_v1",null);
                while(c.moveToNext()){ContentValues v=new ContentValues();v.put("receipt_id","LEGACY-"+c.getLong(0));v.put("device_id","legacy");v.put("created",c.getString(1));v.put("day",c.getString(2));v.put("total",c.getLong(3));v.put("lines",c.getString(4));d.insertWithOnConflict("tx",null,v,SQLiteDatabase.CONFLICT_IGNORE);}c.close();d.execSQL("DROP TABLE tx_legacy_v1");
            }
            ensureSchema(d);
        }
        boolean tableExists(SQLiteDatabase d,String name){Cursor c=d.rawQuery("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",new String[]{name});boolean yes=c.moveToFirst();c.close();return yes;}
        boolean columnExists(SQLiteDatabase d,String table,String column){Cursor c=d.rawQuery("PRAGMA table_info("+table+")",null);boolean yes=false;while(c.moveToNext())if(column.equals(c.getString(1))){yes=true;break;}c.close();return yes;}
        void ensureSchema(SQLiteDatabase d){
            d.execSQL("CREATE TABLE IF NOT EXISTS tx(id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_id TEXT UNIQUE, device_id TEXT, created TEXT, day TEXT, total INTEGER, lines TEXT)");
            d.execSQL("CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT)");
            d.execSQL("CREATE TABLE IF NOT EXISTS catalog(id TEXT PRIMARY KEY, sku TEXT, name TEXT NOT NULL, category TEXT, price INTEGER NOT NULL, active INTEGER DEFAULT 1, updated_at INTEGER)");
            d.execSQL("CREATE TABLE IF NOT EXISTS tx_items(id INTEGER PRIMARY KEY AUTOINCREMENT, receipt_id TEXT, product_id TEXT, name TEXT, price INTEGER, qty INTEGER, subtotal INTEGER)");
            d.execSQL("CREATE TABLE IF NOT EXISTS sync_queue(receipt_id TEXT PRIMARY KEY, payload TEXT NOT NULL, created_at INTEGER, attempts INTEGER DEFAULT 0, last_error TEXT)");
            d.execSQL("CREATE TABLE IF NOT EXISTS remote_tx(receipt_id TEXT PRIMARY KEY, device_id TEXT, created TEXT, total INTEGER, lines_json TEXT, received_at INTEGER)");
        }
        void saveReceiptItems(String receiptId,ArrayList<CartItem> items,ArrayList<Long> nominalLines){
            SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{
                for(CartItem item:items){ContentValues v=new ContentValues();v.put("receipt_id",receiptId);v.put("product_id",item.productId);v.put("name",item.name);v.put("price",item.price);v.put("qty",item.qty);v.put("subtotal",item.subtotal());d.insert("tx_items",null,v);}
                org.json.JSONObject payload=new org.json.JSONObject();payload.put("receipt_id",receiptId);payload.put("device_id",setting("device_id",""));payload.put("created",new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",ID).format(new Date()));payload.put("total",total());org.json.JSONArray lines=new org.json.JSONArray();
                for(long amount:nominalLines)lines.put(new org.json.JSONObject().put("type","nominal").put("amount",amount));
                for(CartItem item:items){org.json.JSONObject x=new org.json.JSONObject();x.put("product_id",item.productId);x.put("name",item.name);x.put("price",item.price);x.put("qty",item.qty);x.put("subtotal",item.subtotal());lines.put(x);}
                payload.put("lines",lines);ContentValues q=new ContentValues();q.put("receipt_id",receiptId);q.put("payload",payload.toString());q.put("created_at",System.currentTimeMillis());d.insertWithOnConflict("sync_queue",null,q,SQLiteDatabase.CONFLICT_REPLACE);d.setTransactionSuccessful();
            }catch(Exception e){}finally{d.endTransaction();}
        }
        String setting(String k,String def){Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{k});String v=def;if(c.moveToFirst())v=c.getString(0);c.close();return v;}
        void setSetting(String k,String v){ContentValues x=new ContentValues();x.put("k",k);x.put("v",v);getWritableDatabase().insertWithOnConflict("settings",null,x,SQLiteDatabase.CONFLICT_REPLACE);}
        long insert(String rid,String did,ArrayList<Long> lines,long total){StringBuilder s=new StringBuilder();for(long n:lines){if(s.length()>0)s.append("|");s.append(n);}String now=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",ID).format(new Date());ContentValues v=new ContentValues();v.put("receipt_id",rid);v.put("device_id",did);v.put("created",now);v.put("day",now.substring(0,10));v.put("total",total);v.put("lines",s.toString());long row=getWritableDatabase().insert("tx",null,v);
            try{org.json.JSONObject p=new org.json.JSONObject();p.put("receipt_id",rid);p.put("device_id",did);p.put("created",now);p.put("total",total);org.json.JSONArray a=new org.json.JSONArray();for(long n:lines)a.put(new org.json.JSONObject().put("type","nominal").put("amount",n));p.put("lines",a);ContentValues q=new ContentValues();q.put("receipt_id",rid);q.put("payload",p.toString());q.put("created_at",System.currentTimeMillis());getWritableDatabase().insertWithOnConflict("sync_queue",null,q,SQLiteDatabase.CONFLICT_REPLACE);}catch(Exception ignored){}return row;}
        Cursor search(String q){return getReadableDatabase().rawQuery("SELECT id,total,receipt_id,created FROM tx WHERE receipt_id LIKE ? OR day LIKE ? ORDER BY id DESC",new String[]{"%"+q+"%","%"+q+"%"});}
        Cursor one(long id){return getReadableDatabase().rawQuery("SELECT receipt_id,created,lines,total FROM tx WHERE id=?",new String[]{""+id});}
        Cursor report(String p,String today){String start=today;if(p.equals("week")){Calendar cal=Calendar.getInstance();cal.add(Calendar.DAY_OF_YEAR,-6);start=new SimpleDateFormat("yyyy-MM-dd",ID).format(cal.getTime());}else if(p.equals("month"))start=today.substring(0,7)+"-01";return getReadableDatabase().rawQuery("SELECT id,total,receipt_id,created FROM tx WHERE day>=? AND day<=? ORDER BY id DESC",new String[]{start,today});}
        void writeCsv(OutputStream out)throws Exception{Writer w=new OutputStreamWriter(out,"UTF-8");w.write("receipt_id,device_id,created,day,total,lines\n");Cursor c=getReadableDatabase().rawQuery("SELECT receipt_id,device_id,created,day,total,lines FROM tx ORDER BY id",null);while(c.moveToNext()){for(int i=0;i<6;i++){if(i>0)w.write(",");String s=c.getString(i);w.write("\""+(s==null?"":s.replace("\"","\"\""))+"\"");}w.write("\n");}c.close();w.flush();}
        void restoreCsv(InputStream in)throws Exception{BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));String line=r.readLine();if(line==null||!line.startsWith("receipt_id,"))throw new Exception("Format backup tidak dikenali");SQLiteDatabase d=getWritableDatabase();d.beginTransaction();try{while((line=r.readLine())!=null){List<String> a=parseCsv(line);if(a.size()<6)continue;ContentValues v=new ContentValues();v.put("receipt_id",a.get(0));v.put("device_id",a.get(1));v.put("created",a.get(2));v.put("day",a.get(3));v.put("total",Long.parseLong(a.get(4)));v.put("lines",a.get(5));d.insertWithOnConflict("tx",null,v,SQLiteDatabase.CONFLICT_IGNORE);}d.setTransactionSuccessful();}finally{d.endTransaction();}}
        List<String> parseCsv(String s){ArrayList<String>a=new ArrayList<>();StringBuilder b=new StringBuilder();boolean q=false;for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c=='"'){if(q&&i+1<s.length()&&s.charAt(i+1)=='"'){b.append('"');i++;}else q=!q;}else if(c==','&&!q){a.add(b.toString());b.setLength(0);}else b.append(c);}a.add(b.toString());return a;}
    }
}
